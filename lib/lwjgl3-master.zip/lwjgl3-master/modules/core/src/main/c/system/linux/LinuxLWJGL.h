/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
#pragma once

#include <X11/X.h>
#include <X11/Xlib.h>
