/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.opencl {
    requires transitive org.lwjgl;

    exports org.lwjgl.opencl;
}