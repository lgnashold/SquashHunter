/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.jawt {
    requires transitive org.lwjgl;

    exports org.lwjgl.system.jawt;
}