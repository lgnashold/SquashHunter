/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.bgfx {
    requires transitive org.lwjgl;
    requires transitive org.lwjgl.bgfx.natives;

    exports org.lwjgl.bgfx;
}