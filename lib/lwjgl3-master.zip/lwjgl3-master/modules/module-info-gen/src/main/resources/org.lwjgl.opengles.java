/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.opengles {
    requires transitive org.lwjgl;
    requires transitive org.lwjgl.opengles.natives;

    exports org.lwjgl.opengles;
}