/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.nanovg {
    requires transitive org.lwjgl;
    requires transitive org.lwjgl.nanovg.natives;

    exports org.lwjgl.nanovg;
}