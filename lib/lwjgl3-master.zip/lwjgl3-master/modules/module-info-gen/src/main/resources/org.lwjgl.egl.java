/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.egl {
    requires transitive org.lwjgl;

    exports org.lwjgl.egl;
}