/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.nuklear {
    requires transitive org.lwjgl;
    requires transitive org.lwjgl.nuklear.natives;

    exports org.lwjgl.nuklear;
}