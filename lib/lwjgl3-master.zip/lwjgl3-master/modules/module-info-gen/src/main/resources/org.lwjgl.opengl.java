/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.opengl {
    requires transitive org.lwjgl;
    requires transitive org.lwjgl.opengl.natives;

    exports org.lwjgl.opengl;
}