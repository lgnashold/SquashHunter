/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
module org.lwjgl.openal {
    requires transitive org.lwjgl;
    requires transitive org.lwjgl.openal.natives;

    exports org.lwjgl.openal;
}